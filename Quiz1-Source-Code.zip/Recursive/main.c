#include <stdio.h>

int factorial (int n)
{   int	temp;	
    if (n == 0)	temp = 1;  
    else temp = n * factorial (n-1);
           
    return	temp; }
int sum(int n)
{   int temp=0, i;
    for(i=1;i<=n;i++) {
        temp = temp + i;
            }
     return temp;       
}
int sumRec(int n)
{   int temp=0;
    if (n==1)
        temp=1;
    else
        temp=sumRec(n-1)+n;
    return temp;       
}
int main(void)
{   int ans, x=5;
    ans = factorial(x);
    printf("factorial ( %d ) = %d \n", x,ans); 
    ans = sum(x);
    printf("Sum of ( %d ) = %d \n", x,ans); 
    ans = sumRec(x);
    printf("Sum Recursive of ( %d ) = %d \n", x,ans); 
    }