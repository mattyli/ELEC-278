#include <stdio.h>

//int x = 5;
int main(void)
{
	//int x=3;
    do { x=1;}
    while(0);
    printf("x value is %d\n",x);
}
	