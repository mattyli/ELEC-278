#include <stdio.h>
int main(void)
{
    int j=3;
    int *pj;
    int **ppj;
    pj = &j;
    ppj = &pj;
    *pj = 8;
	printf("Value of  j is : %d\n",**ppj);
    // another part
    int k=7;
    int *pk;
    int **ppk;
    pk = &k;
    ppk = &pk;
    *pk = 3;
	printf("Value of  k is : %d\n",**ppk);
}
