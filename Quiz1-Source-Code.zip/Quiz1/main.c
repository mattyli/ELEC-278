#include <stdio.h>

int sumOf(int n)
{
    // Sum fuction using Recursion
	int sum;
    if (n == 1)
        sum = 1;
     else
        sum = sumOf( n-1 ) + n;
     return sum;   
}

int sumReg(int n)
{
    // Sum fuction using Recursion
    int sum=0, i;
    for(i=1;i<=n;i++){
        sum = sum + i;
    }
     return sum;   
}

int main( )
{
	int result=0;
    int n=4;
    result = sumOf (n);
    printf("Recursion Sum of %d is %d\n",n,result);
    
	int result2=0;
    int n2=4;
    result2 = sumReg (n2);
    printf("Sum Regular of %d is %d\n",n,result2);
    
}
