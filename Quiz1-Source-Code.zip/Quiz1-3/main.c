#include <stdio.h>

int main(void)
{
    int cm=178;
    int feet, inches;
    feet = cm/2.54/12;
    inches = (178-(feet*12*2.54))/2.54;
    printf("%d\n",feet);
    printf("%d\n",inches);
    printf(" %d cm is equal to %d\" and %d\' ", cm, feet, inches);
    // The output will be
    // 178 cm is equal to 5" and 10'
    printf("\n");
   // He said "don't delay you homework."
   printf("He said \" don\'t delay your homework.\"");
   printf("\n");
}
