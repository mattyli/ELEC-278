#include <stdio.h>
#include <stdlib.h>

int main( )
{
    struct node {
        struct node *next;  
        int	            value;
        };   
    // This part creat a linked list of 5 nodes and populate with values 2, 4, 6, 8, 10
    struct node *nd1 = (struct node *) malloc (sizeof (struct node));
    struct node *nd2 = (struct node *) malloc (sizeof (struct node));
    struct node *nd3 = (struct node *) malloc (sizeof (struct node));
    struct node *nd4 = (struct node *) malloc (sizeof (struct node));
    struct node *nd5 = (struct node *) malloc (sizeof (struct node));
    nd1->value = 2;
    nd2->value = 4;
    nd3->value = 6;
    nd4->value = 8;
    nd5->value = 10;
    nd1->next = nd2;
    nd2->next = nd3;
    nd3->next = nd4;
    nd4->next = nd5;
    nd5->next = NULL;
    struct node *head = (struct node *) malloc (sizeof (struct node));
    struct node *curr = NULL;
    head=nd1;
    curr = head;
    printf("\n");
    int contin=1;
    while (contin) {
        printf("Node value is %d\n",curr->value);
        curr=curr->next;
        if(curr->next == NULL){
            printf("Node value is %d\n",curr->value);
            contin = 0;
        }
    };
    
    // This part example of using next of next of next ...
    int ins = 7;
    curr=head;
    printf("%d\n",curr->value);
    printf("%d\n",curr->next->next->value);    
    
    // This part swap the first node value with the Last Node value.
    struct node *first=NULL, *last=NULL, *temp, *curr2=NULL;
    head = nd1;
    first = head;
    curr2 = head;
    while(curr2->next !=NULL) 
        curr2=curr2->next;
    last = curr2;
    printf("Firrrrst %d\n",first->value);
    printf("Laaaast %d\n",last->value);
    temp->value = first->value;
    first -> value = last -> value;
    last -> value = temp ->value;
    curr2 = head;
    int contin2=1;
    while (contin2) {
        printf("Node value is %d\n",curr2->value);
        curr2=curr2->next;
        if(curr2->next == NULL){
            printf("Node value is %d\n",curr2->value);
            contin2 = 0;
        }
    }
    
 
}
