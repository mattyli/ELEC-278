#include <stdio.h>
int main()
{
    int a=0, b=4, d=9;
    a = b++ + d--;
    printf("Values of a, b, and d : %d, %d, and %d respectively \n\n", a,b,d);

    int c=0, e=4, f=9;
    c = ++e - f--;
    printf("Values of c, e, and f : %d, %d, and %d respectively \n\n", c,e,f);
    
    int i, j, k;
    k = (k=1,j=2,i=3);
    k = k * k;
    printf("k value is : %d \n",k);

    enum results {
        rslt1 = 48, rslt2, rslt3, rslt4
	} ;
   enum results Res;
    printf("Result 1 value is : ---%d---\n", rslt1);
    printf("0x6c & 0xD9 result is :  %d   " , 0x6C&0xD9);
    printf("0x6c  | 0xD9  result is :  %d   " , 0x6C|0xD9);
    printf("\n");
    int z;
    for(z=1;z<4;z++){
        if (z==2) 
            
            continue;
        printf("z value is : %d \n",z);
    }

    struct time {
        unsigned char  hour;
        int                     minute;
    };
    struct time   appointment;
    
    char hr=appointment.hour = 9;
    int  mn=appointment.minute=30;
    printf("\n");
    printf("You have appointment at %d:%d \n",hr,mn);
}