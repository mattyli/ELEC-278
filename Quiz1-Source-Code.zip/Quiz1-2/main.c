#include<stdio.h>

// recursive function for 
// finding prime factor
int primeFactor(int num)
{
    // Prime Factor using Recursion
   int i = 2;
   if(num==1) return;
   while(num%i!=0) i++;
   printf("%d\t",i);
   primeFactor(num/i);
}
int counter=0;
int primeFactor2(int num)
{
    // Prime Factor using Recursion (used for Quiz 1)
   int i = 2;
   if(num==1) return;
   while(num%i != 0) i++;
   counter++;
   printf("Prime Factor %d of %d is %d \n",counter,num,i);
   primeFactor2(num/i);
}
int counter2=0;
int primeFactorReg(int n)
{
    //prime Factor using For loop (used for Quiz 1)
    printf("\n");
    int i;
    for(i=2;i<n;i++)
    {
        if(n%i == 0){
            counter2++;
            printf("Prime Factor %d of %d is %d \n",counter2,n,i);
        }
    }
}

int main()
{
   int number;

   printf("Enter a Positive Integer number: ");
   scanf("%d",&number);

   printf("Prime factors of %d :\n",number);
   primeFactor(number);
   printf("\n");
   
   number=55;
   primeFactor2(number);
   
   number=55;
   primeFactorReg(number);

   return 0;
}