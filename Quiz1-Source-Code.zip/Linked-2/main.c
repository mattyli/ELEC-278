#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	printf("hello world\n");
	//return 0;
    struct node {
        struct node *next;  
        int	            value;
        };
    
    // This part creat a linked list of 5 nodes and populate with values 2, 4, 6, 8, 10
    //struct node *new;
    struct node *new = (struct node *) malloc (sizeof (struct node));
    struct node *nd1 = (struct node *) malloc (sizeof (struct node));
    struct node *nd2 = (struct node *) malloc (sizeof (struct node));
    struct node *nd3 = (struct node *) malloc (sizeof (struct node));
    struct node *nd4 = (struct node *) malloc (sizeof (struct node));
    struct node *nd5 = (struct node *) malloc (sizeof (struct node));
    nd1->value = 2;
    nd2->value = 4;
    nd3->value = 6;
    nd4->value = 8;
    nd5->value = 10;
    nd1->next = nd2;
    nd2->next = nd3;
    nd3->next = nd4;
    nd4->next = nd5;
    nd5->next = NULL;
    struct node *head = (struct node *) malloc (sizeof (struct node));
    struct node *curr = NULL;
    head=nd1;
    curr = head;
    printf("\n");
    int contin=1;
    while (contin) {
        printf("Node value is %d\n",curr->value);
        curr=curr->next;
        if(curr->next == NULL){
            printf("Node value is %d\n",curr->value);
            contin = 0;
        }
    };
    
    
    //This part swap nodes value of 4 with 8 
    struct node *ptr4=NULL, *ptr8=NULL, *ptrTemp, *curr3=NULL;
    
    head = nd1;
    curr3 = head;
    printf("Value of curr3 is : %d\n", curr3->value);
    printf("Value of curr3 is : %d\n", curr3);
    while (curr3  != NULL){ 
        if (curr3->value == 4)
            ptr4 = curr3;
        curr3=curr3->next;
    }
    curr3 = head;
    while (curr3->value !=8) 
        curr3=curr3->next;
    ptr8 = curr3;   
    //ptrTemp = head;
    ptrTemp->value = ptr4 -> value;
    ptr4 -> value = ptr8 -> value;
    ptr8 -> value = ptrTemp -> value;
    
    curr3 = head;
    int contin3=1;
    while (contin3) {
        printf("Node value is %d\n",curr3->value);
        curr3=curr3->next;
        if(curr3->next == NULL){
            printf("Node value is %d\n",curr3->value);
            contin3 = 0;
        };
    };
    
    
}
