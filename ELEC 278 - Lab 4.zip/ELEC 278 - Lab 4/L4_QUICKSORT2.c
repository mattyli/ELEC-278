// Matthew Li - 7346
#include "L4_UTILITYCODE.C"


#define MINSIZE 32 // condition to switch to insertion sort


// the partition and insertion sort functions do not need to be modified
// only the quick sort function needs to be modified to enforce the contstraint
// on partition size

// --------------------- UNCHANGED FUNCTIONS -------------------------------

int insertionsort (int *a, int min, int max)
// Work through array of numbers, placing each one in the correct place. Note
// that insertion sort differs from bubblesort in that with insertion sort, one
// value is moved to its relative place. In bubble sort, the largest value is
// found as the checking keeps choosing the larger of two values to keep
// moving.
{
	int		i, j;
	int		rslt = -1;

	// Check for errors
	if (a == NULL || (min > max))	{
		error ("insertionsort() called with invalid parameters");
	} else	{
		// initialize swaps so we know how many exchanges take place
		//swaps = 0;

		// Outer for loop works through values from min to max. Effectively,
		// we start by making the data in position relative 0 a sorted array containing
		// one element, then adding the rest of the array, one by one, to the
		// sorted part
		for (i = min; i <=max; i++) {
			// Now, i indicates which new element in the array is going to be
			// inserted into its correct position. At the end of each loop, one
			// more value is moved, and all of the bottom is ordered.
			for (j = i; j > min && (a[j - 1] > a[j]); j--) {
				INSTswap(a, j, j - 1);
				}//endfor
			}//endfor
		rslt = intswaps; // minor modification to avoid double counting of swaps
		}//endif
	return 0;
}//insertionsort()

int partition (int  *a,  int left, int right)
{
	int	ll, rr, pivotval;
	ll = left+1;
	rr = right;
	// // choose pivot to be leftmost location
	pivotval = a[left];
	if (verbose)
		printf ("Partition around value in position %d - %d\n", left, a[left]);
    while (ll < rr)	{
		if(a[ll] <= pivotval)	{ ll++; continue;} 		// if one on left less than pivot, leave it alone
        if(a[rr] > pivotval)	{ rr--; continue;} // if one on right greater than pivot, leave it
		swap(a, ll, rr); // both left and right on wrong side - swap them
       	}//endwhile
	
	// we stop when rr and ll collide. Place pivot value such that everything
	// to left is less and everything to right is same or greater.
	
	if (a[ll] < pivotval)	
	{
		swap(a, ll, left);
	} 
	else	
	{
		swap(a, --ll, left);
	}
	return ll;
}//partition()

// --------------------- CHANGED FUNCTIONS -------------------------------

// Will need to call insertion sort within new quicksort function

// QUick/ INsertion sort 
int QUINsort (int *a,  int left, int right)
{
	if (verbose)
		printf ("\nQUINsort: left = %d   right = %d\n", left, right);

	if (left < right)    
    {
        if ((right - left) < MINSIZE)
        {
            iswaps = insertionsort(a, left, right);
        }
		else
		{
			int  pivotndx = partition (a, left, right);
			if (verbose)	
			{
				printf ("    Completed partition, pivot at: %d\n", pivotndx);
				//printarrowatposition (pivotndx);
				printarray (NULL, a, 0, MAXINDEX, 1000);
			}
			QUINsort(a, left, pivotndx-1);
			QUINsort(a, pivotndx+1, right);
		}
	}
	return swaps + iswaps; // return the sum of the insertion + quick sort components
}//QUINsort()
